
</div><!-- /#wrapper -->
<!-- END WRAPPER -->

<!-- BEGIN JS -->
<script src="{!! asset('js/jquery-1.12.4.min.js') !!}"></script>
<script src="{!! asset('plugins/jquery-migrate/jquery-migrate-1.2.1.min.js') !!}"></script>
<script src="{!! asset('js/holder.js') !!}"></script>
<script src="{!! asset('plugins/bootstrap/dist/js/bootstrap.min.js') !!}"></script>
<script src="{!! asset('plugins/metisMenu/dist/metisMenu.min.js') !!}"></script>
<script src="{!! asset('plugins/bootstrap-hover-dropdown/bootstrap-hover-dropdown.min.js') !!}"></script>
<script src="{!! asset('plugins/paper-ripple/dist/PaperRipple.min.js') !!}"></script>
<script src="{!! asset('plugins/malihu-custom-scrollbar-plugin/jquery.mCustomScrollbar.concat.min.js') !!}"></script>
<script src="{!! asset('plugins/sweetalert2/dist/sweetalert2.min.js') !!}"></script>
<script src="{!! asset('plugins/screenfull/dist/screenfull.min.js') !!}"></script>
<script src="{!! asset('plugins/iCheck/icheck.min.js') !!}"></script>
<script src="{!! asset('plugins/switchery/dist/switchery.js') !!}"></script>
<script src="{!! asset('js/core.js') !!}"></script>

<!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
<!--[if lt IE 9]>
<script src="{!! asset('js/html5shiv.js') !!}"></script>
<script src="{!! asset('js/respond.min.js') !!}"></script>
<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
<![endif]-->
<!-- END JS -->

@yield('Pagejavascript')


</body>

</html>