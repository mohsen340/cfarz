@extends('layouts.appT')

@section('content')

    <h2 class="text-center">
       از این ورا ؟
        <br/>
        خوش میگذره ؟ :)
    </h2>


@endsection
