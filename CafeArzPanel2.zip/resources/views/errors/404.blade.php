@extends('layouts.appT')

@section('content')

    <h2 class="text-center">
       ظاهراً خطایی رخ داده است ! :(
    </h2>


@endsection
