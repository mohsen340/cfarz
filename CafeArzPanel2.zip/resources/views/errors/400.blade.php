@extends('layouts.appT')

@section('content')

    <h2 class="text-center">
      شیطونی نکن برادر !
    </h2>


@endsection
