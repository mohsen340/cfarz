<?php $__env->startSection('content'); ?>

    <h2 class="text-center">
       از این ورا ؟
        <br/>
        خوش میگذره ؟ :)
    </h2>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.appT', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>