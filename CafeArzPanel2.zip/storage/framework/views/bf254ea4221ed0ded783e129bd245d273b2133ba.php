<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="portlet box border shadow round">
                <div class="portlet-heading">
                    <div class="portlet-title">
                        <h3 class="title">
                            <i class="icon-fire"></i>
                            اطلاعات کاربر
                        </h3>
                    </div>
                    <div class="buttons-box">
                        <a class="btn btn-sm btn-default btn-round btn-fullscreen" rel="tooltip" title="تمام صفحه" href="#">
                            <i class="icon-size-fullscreen"></i>
                        </a>
                        <a class="btn btn-sm btn-default btn-round btn-collapse" rel="tooltip" title="کوچک کردن" href="#">
                            <i class="icon-arrow-up"></i>
                        </a>
                    </div>
                </div>
                <div class="portlet-body">
                    <div class="portlet-body">

                        <div class="form-group">
                            <h5><label>نام : </label></h5>
                            <div class="input-group round">
                                <span class="desc"> <?php echo e($user->name); ?></span>
                            </div>
                        </div>

                        <div class="form-group">
                            <h5><label>ایمیل : </label></h5>
                            <div class="input-group round">
                                <span class="desc"> <?php echo e($user->email); ?></span>
                            </div>
                        </div>

                        <?php
                        $phone = '';
                        $order = $user->orders()->orderBy('id', 'desc')->first();
                        if($order != null) $phone = $order->phone;
                        ?>

                        <div class="form-group">
                            <h5><label>شماره تلفن : </label></h5>
                            <div class="input-group round">
                                <span class="desc"> <?php echo e($phone); ?></span>
                            </div>
                        </div>

                    </div>
                </div>


            </div>
        </div>












        <div class="col-md-12">
            <div class="portlet box border shadow round">
                <div class="portlet-heading">
                    <div class="portlet-title">
                        <h3 class="title">
                            <i class="icon-user"></i>
                            لیست سفارشات  <?php echo e($user->name); ?>

                        </h3>
                    </div>
                    <div class="buttons-box">

                        <a class="btn btn-sm btn-default btn-round btn-fullscreen" rel="tooltip" title="تمام صفحه" href="#">
                            <i class="icon-size-fullscreen"></i>
                        </a>
                        <a class="btn btn-sm btn-default btn-round btn-collapse" rel="tooltip" title="کوچک کردن" href="#">
                            <i class="icon-arrow-up"></i>
                        </a>

                    </div>
                </div>
                <div class="portlet-body">
                    <div class="portlet-body">

                        <div class="pull-left">
                            <?php echo e($orders->links()); ?>

                        </div>
                        <div class="table-responsive">
                            <table class="table table-condensed table-hover table-striped" id="data-table">
                                <thead>
                                <tr>
                                    <th>ردیف</th>
                                    <th>موبایل</th>
                                    <th>توضیحات</th>
                                    <th>محصول خریداری شده</th>
                                    <th>مبلغ پرداخت شده(تومان)</th>
                                    <th>تاریخ</th>
                                    <th>کد خرید</th>
                                    <th>وضعیت</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php ($i=0); ?>
                                <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($order->is_done == 1): ?>
                                        <tr class="success" style="height: 100px">
                                            <td><?php echo e(++$i); ?></td>
                                            <td> <h4 class="title"><?php echo e($order->phone); ?> </h4></td>
                                            <td> <h4 class="title"><?php echo e($order->description); ?> </h4></td>
                                            <td> <h4 class="desc"><?php echo e($order->product->title); ?> </h4></td>
                                            <td> <h4 class="title"><?php echo e(number_format($order->payment->amount)); ?> </h4></td>
                                            <td> <h4 class="desc"><?php echo e(verta($order->created_at)->format('Y/m/d')); ?><br><?php echo e(verta($order->created_at)->format('H:i')); ?></h4></td>
                                            <td> <h4 class="title"><?php echo e($order->buy_code); ?> </h4></td>
                                            <td> <span class="" style="padding: 2px" >انجام شده </span></td>
                                        </tr>
                                    <?php else: ?>
                                        <tr class="warning" style="height: 100px">
                                            <td><?php echo e(++$i); ?></td>
                                            <td> <h4 class="title"><?php echo e($order->phone); ?> </h4></td>
                                            <td> <h4 class="title"><?php echo e($order->description); ?> </h4></td>
                                            <td> <h4 class="desc"><?php echo e($order->product->title); ?> </h4></td>
                                            <td> <h4 class="title"><?php echo e(number_format($order->payment->amount)); ?> </h4></td>
                                            <td> <h4 class="desc"><?php echo e(verta($order->created_at)->format('Y/m/d')); ?><br><?php echo e(verta($order->created_at)->format('H:i')); ?></h4></td>
                                            <td> <h4 class="title"><?php echo e($order->buy_code); ?> </h4></td>
                                            <td> <a class="btn-success" style="padding: 2px" href="<?php echo e(url('shop-order-done', $order->id)); ?>">انجام شد </a></td>
                                        </tr>
                                        <?php endif; ?>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                </tbody>
                            </table>
                        </div><!-- /.table-responsive -->
                        <div class="pull-left">
                            <?php echo e($orders->links()); ?>

                        </div>
                        <div class="clearfix"></div>
                    </div><!-- /.portlet-body -->
                </div><!-- /.portlet -->
            </div><!-- /.col-md-12 -->
        </div><!-- /.row -->

    </div><!-- /.portlet -->



<?php $__env->stopSection(); ?>

<?php $__env->startSection('Pagejavascript'); ?>


    <!-- BEGIN PAGE JAVASCRIPT -->
    <script src="<?php echo asset('plugins/data-table/js/jquery.dataTables.min.js'); ?>"></script>
    <script src="<?php echo asset('plugins/data-table/js/dataTables.bootstrap.js'); ?>"></script>
    <script src="<?php echo asset('js/pages/datatable.js'); ?>"></script>
    <!-- END PAGE JAVASCRIPT -->

    <script>



    </script>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('PageCss'); ?>

    <!-- BEGIN PAGE CSS -->
    <link href="<?php echo asset('plugins/data-table/css/dataTables.bootstrap.css'); ?>" rel="stylesheet">
    <!-- END PAGE CSS -->

<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.mainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>