<?php $__env->startSection('content'); ?>

    <form id="form" class="m-t-30 m-b-30"  action="<?php echo e(route('login')); ?>" method="POST" role="form">
        <?php echo e(csrf_field()); ?>


        <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
            <label for="email" class="sr-only">رایانامه</label>
            <div class="input-group round">
                                    <span class="input-group-addon">
                                        <i class="icon-envelope"></i>
                                    </span>
                <input id="email" type="email" class="form-control ltr text-left" placeholder="ایمیل" name="email" value="<?php echo e(old('email')); ?>" required autofocus>

            </div><!-- /.input-group -->
            <?php if($errors->has('email')): ?>
                <span class="help-block">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
            <?php endif; ?>
        </div><!-- /.form-group -->

        <div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
            <label for="password" class="sr-only">رمز عبور</label>
            <div class="input-group round">
                                    <span class="input-group-addon">
                                        <i class="icon-key"></i>
                                    </span>
                <input id="password" type="password" class="form-control  ltr text-left" placeholder="رمز عبور" name="password" required>


            </div><!-- /.input-group -->
            <?php if($errors->has('password')): ?>
                <span class="help-block">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
            <?php endif; ?>
        </div><!-- /.form-group -->

        <button class="btn btn-info btn-round btn-block" type="submit">
            <i class="icon-paper-plane font-lg"></i>
            ورود
        </button>

    </form>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.appT', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>