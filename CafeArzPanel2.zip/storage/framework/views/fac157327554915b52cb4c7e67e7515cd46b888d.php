<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <style>
        .text-center1{
            text-align: center;
        }
    </style>
</head>
<body class="rtl">
<div class="mt-5 text-center ">
    <h2 class="m-auto alert alert-danger p-3 text-center1"><?php echo e($description); ?></h2>
    
        
    
</div>
</body>
</html>