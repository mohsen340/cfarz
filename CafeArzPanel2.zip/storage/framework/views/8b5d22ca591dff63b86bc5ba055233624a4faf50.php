<?php echo $__env->make('includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!-- BEGIN PAGE CONTENT -->
<div id="page-content">
    <div class="row">
        <!-- BEGIN BREADCRUMB -->
        <div class="col-md-12">
            <div class="breadcrumb-box border shadow">
                <ul class="breadcrumb">
                    <li><a href="<?php echo e($pageaddress); ?>"><?php echo e($pagename); ?></a></li>
                </ul>
                <div class="breadcrumb-left">
                    <?php echo e($date); ?>    <i class="icon-calendar"></i>
                </div><!-- /.breadcrumb-left -->
            </div><!-- /.breadcrumb-box -->
        </div><!-- /.col-md-12 -->
        <!-- END BREADCRUMB -->

        <div class="col-md-12">
            <?php echo $__env->yieldContent('content'); ?>
        </div><!-- /.col-md-12 -->
    </div><!-- /.row -->

    <div class="row footer-container">
        <div class="col-md-12">
            <div class="copyright">
                <p class="pull-right">
                    کلیه حقوق نزد کافه ارز محفوظ می باشد.
                </p>
            </div><!-- /.copyright -->
        </div><!-- /.col-md-12 -->
    </div><!-- /.row -->
</div><!-- /#page-content -->
<!-- END PAGE CONTENT -->
<?php echo $__env->make('includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
